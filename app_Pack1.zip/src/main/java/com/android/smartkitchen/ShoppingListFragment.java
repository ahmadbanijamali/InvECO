package com.android.smartkitchen;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;




public class ShoppingListFragment extends Fragment implements AsyncResponse1{


    private static final String USER_AGENT = "Mozilla/5.0";
    private static final String URL = "http://crowd-multilogue.com/home/load";

    ImageButton imagebutton;
    TextView txt;
   ListView listView;
    ArrayAdapter<String> adapter;
    String[] price = new String[] {"Prisma: 1.69€","TOKMANNI: 1.49€","SALE: 1:99€","K-Market: 1.7€"};


    public ShoppingListFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        final ShoppingListFragment myShoppingListfragment = this;
        View views = inflater.inflate(R.layout.fragment_shopping_list, container, false);

        MyDownloadTask1 myDownloadTask1 = new MyDownloadTask1();
        myDownloadTask1.delegate = myShoppingListfragment;
        myDownloadTask1.execute();

        imagebutton = (ImageButton) views.findViewById(R.id.Image1);
        txt = (TextView)views.findViewById(R.id.Noshop);

        listView = (ListView) views.findViewById((R.id.ShopList));


        imagebutton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent browserintent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.fi/maps/place/K-market+Katajanokka/@60.1672275,24.9626766,19z/data=!4m12!1m6!3m5!1s0x46920bc38044c4ed:0x6fb7a0516f3f72a8!2sWanha+Satama+Brasserie!8m2!3d60.1656953!4d24.9665407!3m4!1s0x0:0xef45b35520bd2c71!8m2!3d60.167446!4d24.9622142?hl=en"));
                startActivity(browserintent);
            }

        });

        return views;
    }

    @Override
    public void processFinish(String output) {

        String Stringinput =output.split("-")[0];
        Float Floatinput= Float.valueOf(Stringinput);

        if (Floatinput>1000){

            imagebutton.setVisibility(View.GONE);
            adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,price);
            listView.setAdapter(adapter);
            listView.setVisibility(View.GONE);
            txt.setText("No Shpping Needed :)");


        }

        else {

            imagebutton.setVisibility(View.VISIBLE);
            adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,price);
            listView.setAdapter(adapter);
            listView.setVisibility(View.VISIBLE);
            txt.setVisibility(View.GONE);


        }


    }



}
interface AsyncResponse1{
    void processFinish(String output);
}

class MyDownloadTask1 extends AsyncTask<Void,Void,Void> {
    public AsyncResponse1 delegate = null;
    String responseMsg = "No";

    @Override
    protected void onPreExecute() {
    }

    @Override
    protected Void doInBackground(Void... params) {
        try {
            URL url = new URL("http://crowd-multilogue.com/home/load");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            try {
                con.setRequestMethod("GET");
                responseMsg = con.getResponseMessage();
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line + "\n");
                }
                br.close();
                responseMsg = sb.toString();
            } catch (Exception e) {
            } finally {
                con.disconnect();
            }
        } catch (Exception e) {
            responseMsg = e.getMessage();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void output) {
        delegate.processFinish(responseMsg);
    }
}